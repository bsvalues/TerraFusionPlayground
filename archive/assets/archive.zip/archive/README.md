﻿# TerraFusion Archive Directory

## Purpose
This directory contains files that have been moved from the main codebase for better organization.

## Contents
- generated-icon.png: Auto-generated application icon
- capabilities.json: System capabilities configuration

## Restoration
If any archived file is needed:
1. Move it back to the appropriate location
2. Update any import paths or references
3. Update this documentation

## Last Updated
2025-06-05 17:09:10

